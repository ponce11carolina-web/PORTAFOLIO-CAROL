<!DOCTYPE html>


<html lang="en-US">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<link rel="pingback" href="https://wp.dreamitsolution.net/dreamer/portfolio/xmlrpc.php">

	<title>Page not found &#8211; Al-Amindream</title>
<meta name='robots' content='max-image-preview:large' />
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//cdnjs.cloudflare.com' />
<link rel='dns-prefetch' href='//fonts.cdnfonts.com' />
<link rel="alternate" type="application/rss+xml" title="Al-Amindream &raquo; Feed" href="https://wp.dreamitsolution.net/dreamer/portfolio/feed/" />
<link rel="alternate" type="application/rss+xml" title="Al-Amindream &raquo; Comments Feed" href="https://wp.dreamitsolution.net/dreamer/portfolio/comments/feed/" />
<style id="wp-img-auto-sizes-contain-inline-css">
img:is([sizes=auto i],[sizes^="auto," i]){contain-intrinsic-size:3000px 1500px}
/*# sourceURL=wp-img-auto-sizes-contain-inline-css */
</style>
<link rel='stylesheet' id='givewp-campaign-blocks-fonts-css' href='https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&#038;display=swap&#038;ver=7.1.4' media='all' />
<link rel='stylesheet' id='hfe-widgets-style-css' href='https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/plugins/header-footer-elementor/inc/widgets-css/frontend.css?ver=2.8.7' media='all' />
<style id="wp-emoji-styles-inline-css">

	img.wp-smiley, img.emoji {
		display: inline !important;
		border: none !important;
		box-shadow: none !important;
		height: 1em !important;
		width: 1em !important;
		margin: 0 0.07em !important;
		vertical-align: -0.1em !important;
		background: none !important;
		padding: 0 !important;
	}
/*# sourceURL=wp-emoji-styles-inline-css */
</style>
<link rel='stylesheet' id='wp-block-library-css' href='https://wp.dreamitsolution.net/dreamer/portfolio/wp-includes/css/dist/block-library/style.min.css?ver=7.1.4' media='all' />
<style id="classic-theme-styles-inline-css">
/*! This file is auto-generated */
.wp-block-button__link{color:#fff;background-color:#32373c;border-radius:9999px;box-shadow:none;text-decoration:none;padding:calc(.667em + 2px) calc(1.333em + 2px);font-size:1.125em}.wp-block-file__button{background:#32373c;color:#fff;text-decoration:none}
/*# sourceURL=/wp-includes/css/classic-themes.min.css */
</style>
<style id="givewp-campaign-comments-block-style-inline-css">
.givewp-campaign-comment-block-card{display:flex;gap:var(--givewp-spacing-3);padding:var(--givewp-spacing-4) 0}.givewp-campaign-comment-block-card__avatar{align-items:center;border-radius:50%;display:flex;height:40px;justify-content:center;width:40px}.givewp-campaign-comment-block-card__avatar img{align-items:center;border-radius:50%;display:flex;height:auto;justify-content:center;min-width:40px;width:100%}.givewp-campaign-comment-block-card__donor-name{color:var(--givewp-neutral-700);font-size:1rem;font-weight:600;line-height:1.5;margin:0;text-align:left}.givewp-campaign-comment-block-card__details{align-items:center;color:var(--givewp-neutral-400);display:flex;font-size:.875rem;font-weight:500;gap:var(--givewp-spacing-2);height:auto;line-height:1.43;margin:2px 0 var(--givewp-spacing-3) 0;text-align:left}.givewp-campaign-comment-block-card__comment{color:var(--givewp-neutral-700);font-size:1rem;line-height:1.5;margin:0;text-align:left}.givewp-campaign-comment-block-card__read-more{background:none;border:none;color:var(--givewp-blue-500);cursor:pointer;font-size:.875rem;line-height:1.43;outline:none;padding:0}
.givewp-campaign-comments-block-empty-state{align-items:center;background-color:var(--givewp-shades-white);border:1px solid var(--givewp-neutral-50);border-radius:.5rem;display:flex;flex-direction:column;justify-content:center;padding:var(--givewp-spacing-6)}.givewp-campaign-comments-block-empty-state__details{align-items:center;display:flex;flex-direction:column;gap:var(--givewp-spacing-1);justify-content:center;margin:.875rem 0}.givewp-campaign-comments-block-empty-state__title{color:var(--givewp-neutral-700);font-size:1rem;font-weight:500;margin:0}.givewp-campaign-comments-block-empty-state__description{color:var(--givewp-neutral-700);font-size:.875rem;line-height:1.43;margin:0}
.givewp-campaign-comment-block{background-color:var(--givewp-shades-white);display:flex;flex-direction:column;gap:var(--givewp-spacing-2);padding:var(--givewp-spacing-6) 0}.givewp-campaign-comment-block__title{color:var(--givewp-neutral-900);font-size:18px;font-weight:600;line-height:1.56;margin:0;text-align:left}.givewp-campaign-comment-block__cta{align-items:center;background-color:var(--givewp-neutral-50);border-radius:4px;color:var(--giewp-neutral-500);display:flex;font-size:14px;font-weight:600;gap:8px;height:36px;line-height:1.43;margin:0;padding:var(--givewp-spacing-2) var(--givewp-spacing-4);text-align:left}

/*# sourceURL=https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/plugins/give/build/campaignCommentsBlockApp.css */
</style>
<style id="givewp-campaign-cover-block-style-inline-css">
.givewp-campaign-selector{border:1px solid #e5e7eb;border-radius:5px;box-shadow:0 2px 4px 0 rgba(0,0,0,.05);display:flex;flex-direction:column;gap:20px;padding:40px 24px}.givewp-campaign-selector__label{padding-bottom:16px}.givewp-campaign-selector__select input[type=text]:focus{border-color:transparent;box-shadow:0 0 0 1px transparent;outline:2px solid transparent}.givewp-campaign-selector__logo{align-self:center}.givewp-campaign-selector__open{background:#2271b1;border:none;border-radius:5px;color:#fff;cursor:pointer;padding:.5rem 1rem}.givewp-campaign-selector__submit{background-color:#27ae60;border:0;border-radius:5px;color:#fff;font-weight:700;outline:none;padding:1rem;text-align:center;transition:.2s;width:100%}.givewp-campaign-selector__submit:disabled{background-color:#f3f4f6;color:#9ca0af}.givewp-campaign-selector__submit:hover:not(:disabled){cursor:pointer;filter:brightness(1.2)}
.givewp-campaign-cover-block__button{align-items:center;border:1px solid #2271b1;border-radius:2px;color:#2271b1;display:flex;justify-content:center;margin-bottom:.5rem;min-height:32px;width:100%}.givewp-campaign-cover-block__image{border-radius:2px;display:flex;flex-grow:1;margin-bottom:.5rem;max-height:4.44rem;-o-object-fit:cover;object-fit:cover;width:100%}.givewp-campaign-cover-block__help-text{color:#4b5563;font-size:.75rem;font-stretch:normal;font-style:normal;font-weight:400;letter-spacing:normal;line-height:1.4;text-align:left}.givewp-campaign-cover-block__edit-campaign-link{align-items:center;display:inline-flex;font-size:.75rem;font-stretch:normal;font-style:normal;font-weight:400;gap:.125rem;line-height:1.4}.givewp-campaign-cover-block__edit-campaign-link svg{fill:currentColor;height:1.25rem;width:1.25rem}.givewp-campaign-cover-block-preview__image{align-items:center;display:flex;height:100%;justify-content:center;width:100%}

/*# sourceURL=https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/plugins/give/build/campaignCoverBlock.css */
</style>
<style id="givewp-campaign-donations-style-inline-css">
.givewp-campaign-donations-block{padding:1.5rem 0}.givewp-campaign-donations-block *{font-family:Inter,sans-serif}.givewp-campaign-donations-block .givewp-campaign-donations-block__header{align-items:center;display:flex;justify-content:space-between;margin-bottom:.5rem}.givewp-campaign-donations-block .givewp-campaign-donations-block__title{color:var(--givewp-neutral-900);font-size:1.125rem;font-weight:600;line-height:1.56;margin:0}.givewp-campaign-donations-block .givewp-campaign-donations-block__donations{display:grid;gap:.5rem;margin:0;padding:0}.givewp-campaign-donations-block .givewp-campaign-donations-block__donation,.givewp-campaign-donations-block .givewp-campaign-donations-block__empty-state{background-color:var(--givewp-shades-white);border:1px solid var(--givewp-neutral-50);border-radius:.5rem;display:flex;padding:1rem}.givewp-campaign-donations-block .givewp-campaign-donations-block__donation{align-items:center;gap:.75rem}.givewp-campaign-donations-block .givewp-campaign-donations-block__donation-icon{align-items:center;display:flex}.givewp-campaign-donations-block .givewp-campaign-donations-block__donation-icon img{border-radius:100%;height:2.5rem;-o-object-fit:cover;object-fit:cover;width:2.5rem}.givewp-campaign-donations-block .givewp-campaign-donations-block__donation-info{display:flex;flex-direction:column;justify-content:center;row-gap:.25rem}.givewp-campaign-donations-block .givewp-campaign-donations-block__donation-description{color:var(--givewp-neutral-500);font-size:1rem;font-weight:500;line-height:1.5;margin:0}.givewp-campaign-donations-block .givewp-campaign-donations-block__donation-description strong{color:var(--givewp-neutral-700);font-weight:600}.givewp-campaign-donations-block .givewp-campaign-donations-block__donation-date{align-items:center;color:var(--givewp-neutral-400);display:flex;font-size:.875rem;font-weight:500;line-height:1.43}.givewp-campaign-donations-block .givewp-campaign-donations-block__donation-ribbon{align-items:center;border-radius:100%;color:#1f2937;display:flex;height:1.25rem;justify-content:center;margin-left:auto;width:1.25rem}.givewp-campaign-donations-block .givewp-campaign-donations-block__donation-ribbon[data-position="1"]{background-color:gold}.givewp-campaign-donations-block .givewp-campaign-donations-block__donation-ribbon[data-position="2"]{background-color:silver}.givewp-campaign-donations-block .givewp-campaign-donations-block__donation-ribbon[data-position="3"]{background-color:#cd7f32;color:#fffaf2}.givewp-campaign-donations-block .givewp-campaign-donations-block__donation-amount{color:var(--givewp-neutral-700);font-size:1.125rem;font-weight:600;line-height:1.56;margin-left:auto}.givewp-campaign-donations-block .givewp-campaign-donations-block__footer{display:flex;justify-content:center;margin-top:.5rem}.givewp-campaign-donations-block .givewp-campaign-donations-block__donate-button button.givewp-donation-form-modal__open,.givewp-campaign-donations-block .givewp-campaign-donations-block__empty-button button.givewp-donation-form-modal__open,.givewp-campaign-donations-block .givewp-campaign-donations-block__load-more-button{background:none!important;border:1px solid var(--givewp-primary-color);border-radius:.5rem;color:var(--givewp-primary-color)!important;font-size:.875rem;font-weight:600;line-height:1.43;padding:.25rem 1rem!important}.givewp-campaign-donations-block .givewp-campaign-donations-block__donate-button button.givewp-donation-form-modal__open:hover,.givewp-campaign-donations-block .givewp-campaign-donations-block__empty-button button.givewp-donation-form-modal__open:hover,.givewp-campaign-donations-block .givewp-campaign-donations-block__load-more-button:hover{background:var(--givewp-primary-color)!important;color:var(--givewp-shades-white)!important}.givewp-campaign-donations-block .givewp-campaign-donations-block__empty-state{align-items:center;flex-direction:column;padding:1.5rem}.givewp-campaign-donations-block .givewp-campaign-donations-block__empty-description,.givewp-campaign-donations-block .givewp-campaign-donations-block__empty-title{color:var(--givewp-neutral-700);margin:0}.givewp-campaign-donations-block .givewp-campaign-donations-block__empty-title{font-size:1rem;font-weight:500;line-height:1.5}.givewp-campaign-donations-block .givewp-campaign-donations-block__empty-description{font-size:.875rem;line-height:1.43;margin-top:.25rem}.givewp-campaign-donations-block .givewp-campaign-donations-block__empty-icon{color:var(--givewp-secondary-color);margin-bottom:.875rem;order:-1}.givewp-campaign-donations-block .givewp-campaign-donations-block__empty-button{margin-top:.875rem}.givewp-campaign-donations-block .givewp-campaign-donations-block__empty-button button.givewp-donation-form-modal__open{border-radius:.25rem;padding:.5rem 1rem!important}

/*# sourceURL=https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/plugins/give/build/campaignDonationsBlockApp.css */
</style>
<style id="givewp-campaign-donors-style-inline-css">
.givewp-campaign-donors-block{padding:1.5rem 0}.givewp-campaign-donors-block *{font-family:Inter,sans-serif}.givewp-campaign-donors-block .givewp-campaign-donors-block__header{align-items:center;display:flex;justify-content:space-between;margin-bottom:.5rem}.givewp-campaign-donors-block .givewp-campaign-donors-block__title{color:var(--givewp-neutral-900);font-size:1.125rem;font-weight:600;line-height:1.56;margin:0}.givewp-campaign-donors-block .givewp-campaign-donors-block__donors{display:grid;gap:.5rem;margin:0;padding:0}.givewp-campaign-donors-block .givewp-campaign-donors-block__donor,.givewp-campaign-donors-block .givewp-campaign-donors-block__empty-state{background-color:var(--givewp-shades-white);border:1px solid var(--givewp-neutral-50);border-radius:.5rem;display:flex;padding:1rem}.givewp-campaign-donors-block .givewp-campaign-donors-block__donor{align-items:center;gap:.75rem}.givewp-campaign-donors-block .givewp-campaign-donors-block__donor-avatar{align-items:center;display:flex}.givewp-campaign-donors-block .givewp-campaign-donors-block__donor-avatar img{border-radius:100%;height:2.5rem;-o-object-fit:cover;object-fit:cover;width:2.5rem}.givewp-campaign-donors-block .givewp-campaign-donors-block__donor-info{align-items:center;display:flex;flex-wrap:wrap;row-gap:.25rem}.givewp-campaign-donors-block .givewp-campaign-donors-block__donor-name{color:var(--givewp-neutral-900);font-size:1rem;font-weight:600;line-height:1.5;margin:0}.givewp-campaign-donors-block .givewp-campaign-donors-block__donor-date{align-items:center;color:var(--givewp-neutral-400);display:flex;font-size:.875rem;font-weight:500;line-height:1.43}.givewp-campaign-donors-block .givewp-campaign-donors-block__donor-date:before{background:var(--givewp-neutral-100);border-radius:100%;content:"";display:block;height:.25rem;margin:0 .5rem;width:.25rem}.givewp-campaign-donors-block .givewp-campaign-donors-block__donor-ribbon{align-items:center;border-radius:100%;color:#1f2937;display:flex;height:1.25rem;justify-content:center;margin-left:.5rem;width:1.25rem}.givewp-campaign-donors-block .givewp-campaign-donors-block__donor-ribbon[data-position="1"]{background-color:gold}.givewp-campaign-donors-block .givewp-campaign-donors-block__donor-ribbon[data-position="2"]{background-color:silver}.givewp-campaign-donors-block .givewp-campaign-donors-block__donor-ribbon[data-position="3"]{background-color:#cd7f32;color:#fffaf2}.givewp-campaign-donors-block .givewp-campaign-donors-block__donor-company{color:var(--givewp-neutral-400);display:flex;flex:0 0 100%;font-size:.875rem;font-weight:500;line-height:1.43}.givewp-campaign-donors-block .givewp-campaign-donors-block__donor-amount{color:var(--givewp-neutral-700);font-size:1.125rem;font-weight:600;line-height:1.56;margin-left:auto}.givewp-campaign-donors-block .givewp-campaign-donors-block__footer{display:flex;justify-content:center;margin-top:.5rem}.givewp-campaign-donors-block .givewp-campaign-donors-block__donate-button button.givewp-donation-form-modal__open,.givewp-campaign-donors-block .givewp-campaign-donors-block__empty-button button.givewp-donation-form-modal__open,.givewp-campaign-donors-block .givewp-campaign-donors-block__load-more-button{background:none!important;border:1px solid var(--givewp-primary-color);border-radius:.5rem;color:var(--givewp-primary-color)!important;font-size:.875rem;font-weight:600;line-height:1.43;padding:.25rem 1rem!important}.givewp-campaign-donors-block .givewp-campaign-donors-block__donate-button button.givewp-donation-form-modal__open:hover,.givewp-campaign-donors-block .givewp-campaign-donors-block__empty-button button.givewp-donation-form-modal__open:hover,.givewp-campaign-donors-block .givewp-campaign-donors-block__load-more-button:hover{background:var(--givewp-primary-color)!important;color:var(--givewp-shades-white)!important}.givewp-campaign-donors-block .givewp-campaign-donors-block__empty-state{align-items:center;flex-direction:column;padding:1.5rem}.givewp-campaign-donors-block .givewp-campaign-donors-block__empty-description,.givewp-campaign-donors-block .givewp-campaign-donors-block__empty-title{color:var(--givewp-neutral-700);margin:0}.givewp-campaign-donors-block .givewp-campaign-donors-block__empty-title{font-size:1rem;font-weight:500;line-height:1.5}.givewp-campaign-donors-block .givewp-campaign-donors-block__empty-description{font-size:.875rem;line-height:1.43;margin-top:.25rem}.givewp-campaign-donors-block .givewp-campaign-donors-block__empty-icon{color:var(--givewp-secondary-color);margin-bottom:.875rem;order:-1}.givewp-campaign-donors-block .givewp-campaign-donors-block__empty-button{margin-top:.875rem}.givewp-campaign-donors-block .givewp-campaign-donors-block__empty-button button.givewp-donation-form-modal__open{border-radius:.25rem;padding:.5rem 1rem!important}

/*# sourceURL=https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/plugins/give/build/campaignDonorsBlockApp.css */
</style>
<style id="givewp-campaign-form-style-inline-css">
.givewp-donation-form-modal{outline:none;overflow-y:scroll;padding:1rem;width:100%}.givewp-donation-form-modal[data-entering=true]{animation:modal-fade .3s,modal-zoom .6s}@keyframes modal-fade{0%{opacity:0}to{opacity:1}}@keyframes modal-zoom{0%{transform:scale(.8)}to{transform:scale(1)}}.givewp-donation-form-modal__overlay{align-items:center;background:rgba(0,0,0,.7);display:flex;flex-direction:column;height:100dvh;justify-content:center;left:0;position:fixed;top:0;width:100vw;z-index:100}.givewp-donation-form-modal__overlay[data-loading=true]{display:none}.givewp-donation-form-modal__overlay[data-entering=true]{animation:modal-fade .3s}.givewp-donation-form-modal__overlay[data-exiting=true]{animation:modal-fade .15s ease-in reverse}.givewp-donation-form-modal__open__spinner{left:50%;line-height:1;position:absolute;top:50%;transform:translate(-50%,-50%);z-index:100}.givewp-donation-form-modal__open{position:relative}.givewp-donation-form-modal__close{background:#e7e8ed;border:1px solid transparent;border-radius:50%;cursor:pointer;display:flex;padding:.75rem;position:fixed;right:25px;top:25px;transition:.2s;width:-moz-fit-content;width:fit-content;z-index:999}.givewp-donation-form-modal__close svg{height:1rem;width:1rem}.givewp-donation-form-modal__close:active,.givewp-donation-form-modal__close:focus,.givewp-donation-form-modal__close:hover{background-color:#caccd7;border:1px solid #caccd7}.admin-bar .givewp-donation-form-modal{margin-top:32px}.admin-bar .givewp-donation-form-modal__close{top:57px}
.givewp-entity-selector{border:1px solid #e5e7eb;border-radius:5px;box-shadow:0 2px 4px 0 rgba(0,0,0,.05);display:flex;flex-direction:column;gap:20px;padding:40px 24px}.givewp-entity-selector__label{padding-bottom:16px}.givewp-entity-selector__select input[type=text]:focus{border-color:transparent;box-shadow:0 0 0 1px transparent;outline:2px solid transparent}.givewp-entity-selector__logo{align-self:center}.givewp-entity-selector__open{background:#2271b1;border:none;border-radius:5px;color:#fff;cursor:pointer;padding:.5rem 1rem}.givewp-entity-selector__submit{background-color:#27ae60;border:0;border-radius:5px;color:#fff;font-weight:700;outline:none;padding:1rem;text-align:center;transition:.2s;width:100%}.givewp-entity-selector__submit:disabled{background-color:#f3f4f6;color:#9ca0af}.givewp-entity-selector__submit:hover:not(:disabled){cursor:pointer;filter:brightness(1.2)}
.givewp-campaign-selector{border:1px solid #e5e7eb;border-radius:5px;box-shadow:0 2px 4px 0 rgba(0,0,0,.05);display:flex;flex-direction:column;gap:20px;padding:40px 24px}.givewp-campaign-selector__label{padding-bottom:16px}.givewp-campaign-selector__select input[type=text]:focus{border-color:transparent;box-shadow:0 0 0 1px transparent;outline:2px solid transparent}.givewp-campaign-selector__logo{align-self:center}.givewp-campaign-selector__open{background:#2271b1;border:none;border-radius:5px;color:#fff;cursor:pointer;padding:.5rem 1rem}.givewp-campaign-selector__submit{background-color:#27ae60;border:0;border-radius:5px;color:#fff;font-weight:700;outline:none;padding:1rem;text-align:center;transition:.2s;width:100%}.givewp-campaign-selector__submit:disabled{background-color:#f3f4f6;color:#9ca0af}.givewp-campaign-selector__submit:hover:not(:disabled){cursor:pointer;filter:brightness(1.2)}
.givewp-donation-form-link,.givewp-donation-form-modal__open{background:var(--givewp-primary-color,#2271b1);border:none;border-radius:5px;color:#fff;cursor:pointer;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen-Sans,Ubuntu,Cantarell,Helvetica Neue,sans-serif;font-size:1rem;font-weight:500!important;line-height:1.5;padding:.75rem 1.25rem!important;text-decoration:none!important;transition:all .2s ease;width:100%}.givewp-donation-form-link:active,.givewp-donation-form-link:focus,.givewp-donation-form-link:focus-visible,.givewp-donation-form-link:hover,.givewp-donation-form-modal__open:active,.givewp-donation-form-modal__open:focus,.givewp-donation-form-modal__open:focus-visible,.givewp-donation-form-modal__open:hover{background-color:color-mix(in srgb,var(--givewp-primary-color,#2271b1),#000 20%)}.components-input-control__label{width:100%}.wp-block-givewp-campaign-form{position:relative}.wp-block-givewp-campaign-form form[id*=give-form] #give-gateway-radio-list>li input[type=radio]{display:inline-block}.wp-block-givewp-campaign-form iframe{pointer-events:none;width:100%!important}.give-change-donation-form-btn svg{margin-top:3px}.givewp-default-form-toggle{margin-top:var(--givewp-spacing-4)}

/*# sourceURL=https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/plugins/give/build/campaignFormBlock.css */
</style>
<style id="givewp-campaign-goal-style-inline-css">
.givewp-campaign-goal{display:flex;flex-direction:column;gap:.5rem;padding-bottom:1rem}.givewp-campaign-goal__container{display:flex;flex-direction:row;justify-content:space-between}.givewp-campaign-goal__container-item{display:flex;flex-direction:column;gap:.2rem}.givewp-campaign-goal__container-item span{color:var(--givewp-neutral-500);font-size:12px;font-weight:600;letter-spacing:.48px;line-height:1.5;text-transform:uppercase}.givewp-campaign-goal__container-item strong{color:var(--givewp-neutral-900);font-size:20px;font-weight:600;line-height:1.6}.givewp-campaign-goal__progress-bar{display:flex}.givewp-campaign-goal__progress-bar-container{background-color:#f2f2f2;border-radius:14px;box-shadow:inset 0 1px 4px 0 rgba(0,0,0,.09);display:flex;flex-grow:1;height:8px}.givewp-campaign-goal__progress-bar-progress{background:var(--givewp-secondary-color,#2d802f);border-radius:14px;box-shadow:inset 0 1px 4px 0 rgba(0,0,0,.09);display:flex;height:8px}

/*# sourceURL=https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/plugins/give/build/campaignGoalBlockApp.css */
</style>
<style id="givewp-campaign-stats-block-style-inline-css">
.givewp-campaign-stats-block span{color:var(--givewp-neutral-500);display:block;font-size:12px;font-weight:600;letter-spacing:.48px;line-height:1.5;margin-bottom:2px;text-align:left;text-transform:uppercase}.givewp-campaign-stats-block strong{color:var(--givewp-neutral-900);font-size:20px;font-weight:600;letter-spacing:normal;line-height:1.6}

/*# sourceURL=https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/plugins/give/build/campaignStatsBlockApp.css */
</style>
<style id="givewp-campaign-donate-button-style-inline-css">
.givewp-donation-form-link,.givewp-donation-form-modal__open{background:var(--givewp-primary-color,#2271b1);border:none;border-radius:5px;color:#fff;cursor:pointer;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen-Sans,Ubuntu,Cantarell,Helvetica Neue,sans-serif;font-size:1rem;font-weight:500!important;line-height:1.5;padding:.75rem 1.25rem!important;text-decoration:none!important;transition:all .2s ease;width:100%}.givewp-donation-form-link:active,.givewp-donation-form-link:focus,.givewp-donation-form-link:focus-visible,.givewp-donation-form-link:hover,.givewp-donation-form-modal__open:active,.givewp-donation-form-modal__open:focus,.givewp-donation-form-modal__open:focus-visible,.givewp-donation-form-modal__open:hover{background-color:color-mix(in srgb,var(--givewp-primary-color,#2271b1),#000 20%)}.give-change-donation-form-btn svg{margin-top:3px}.givewp-default-form-toggle{margin-top:var(--givewp-spacing-4)}

/*# sourceURL=https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/plugins/give/build/campaignDonateButtonBlockApp.css */
</style>
<style id="global-styles-inline-css">
:root{--wp--preset--aspect-ratio--square: 1;--wp--preset--aspect-ratio--4-3: 4/3;--wp--preset--aspect-ratio--3-4: 3/4;--wp--preset--aspect-ratio--3-2: 3/2;--wp--preset--aspect-ratio--2-3: 2/3;--wp--preset--aspect-ratio--16-9: 16/9;--wp--preset--aspect-ratio--9-16: 9/16;--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgb(6,147,227) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgb(252,185,0) 0%,rgb(255,105,0) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgb(255,105,0) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgb(255, 255, 255), 6px 6px rgb(0, 0, 0);--wp--preset--shadow--crisp: 6px 6px 0px rgb(0, 0, 0);}.wp-block-button{--wp--preset--dimension--25: 25%;--wp--preset--dimension--50: 50%;--wp--preset--dimension--75: 75%;--wp--preset--dimension--100: 100%;}:where(body) { margin: 0; }:where(.is-layout-flex){gap: 0.5em;}:where(.is-layout-grid){gap: 0.5em;}body .is-layout-flex{display: flex;}.is-layout-flex{flex-wrap: wrap;align-items: center;}.is-layout-flex > :is(*, div){margin: 0;}body .is-layout-grid{display: grid;}.is-layout-grid > :is(*, div){margin: 0;}body{padding-top: 0px;padding-right: 0px;padding-bottom: 0px;padding-left: 0px;}:root :where(.wp-element-button, .wp-block-button__link){background-color: #32373c;border-width: 0;color: #fff;font-family: inherit;font-size: inherit;font-style: inherit;font-weight: inherit;letter-spacing: inherit;line-height: inherit;padding-top: calc(0.667em + 2px);padding-right: calc(1.333em + 2px);padding-bottom: calc(0.667em + 2px);padding-left: calc(1.333em + 2px);text-decoration: none;text-transform: inherit;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
:root :where(.wp-block-icon svg){width: 24px;}
:where(.wp-block-gallery.is-layout-flex){gap: var( --wp--style--gallery-gap-default, var( --gallery-block--gutter-size, var( --wp--style--block-gap, 0.5em ) ) );}:where(.wp-block-gallery.is-layout-grid){gap: var( --wp--style--gallery-gap-default, var( --gallery-block--gutter-size, var( --wp--style--block-gap, 0.5em ) ) );}
:where(.wp-block-latest-posts.is-layout-flex){gap: 1.25em;}:where(.wp-block-latest-posts.is-layout-grid){gap: 1.25em;}
:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}
:where(.wp-block-term-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-term-template.is-layout-grid){gap: 1.25em;}
:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}
:root :where(.wp-block-pullquote){font-size: 1.5em;line-height: 1.6;}
/*# sourceURL=global-styles-inline-css */
</style>
<link rel='stylesheet' id='contact-form-7-css' href='https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=6.1.6' media='all' />
<link rel='stylesheet' id='give-styles-css' href='https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/plugins/give/build/assets/dist/css/give.css?ver=4.15.2' media='all' />
<link rel='stylesheet' id='givewp-design-system-foundation-css' href='https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/plugins/give/build/assets/dist/css/design-system/foundation.css?ver=1.2.0' media='all' />
<link rel='stylesheet' id='hfe-style-css' href='https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/plugins/header-footer-elementor/assets/css/header-footer-elementor.css?ver=2.8.7' media='all' />
<link rel='stylesheet' id='elementor-frontend-css' href='https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/plugins/elementor/assets/css/frontend.min.css?ver=4.0.9' media='all' />
<link rel='stylesheet' id='elementor-post-7-css' href='https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/uploads/elementor/css/post-7.css?ver=1793528836' media='all' />
<link rel='stylesheet' id='owl-style-css' href='https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/plugins/dreamit-elementor-extension/assets/css/owl.carousel.css?ver=7.1.4' media='all' />
<link rel='stylesheet' id='owl-theme-css' href='https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css?ver=7.1.4' media='all' />
<link rel='stylesheet' id='style3-css' href='https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/plugins/dreamit-elementor-extension/assets/css/widgets-style-3.css?ver=7.1.4' media='all' />
<link rel='stylesheet' id='style2-css' href='https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/plugins/dreamit-elementor-extension/assets/css/widgets-style-2.css?ver=7.1.4' media='all' />
<link rel='stylesheet' id='style1-css' href='https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/plugins/dreamit-elementor-extension/assets/css/widgets-style.css?ver=7.1.4' media='all' />
<link rel='stylesheet' id='responsive1-css' href='https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/plugins/dreamit-elementor-extension/assets/css/widget-responsive.css?ver=7.1.4' media='all' />
<link rel='stylesheet' id='ai-animation-css' href='https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/plugins/dreamit-elementor-extension/assets/css/ai-animation.css?ver=7.1.4' media='all' />
<link rel='stylesheet' id='flaticon-css' href='https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/plugins/dreamit-elementor-extension/assets/css/flaticon.css?ver=7.1.4' media='all' />
<link rel='stylesheet' id='elementor-post-165-css' href='https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/uploads/elementor/css/post-165.css?ver=1793528836' media='all' />
<link rel='stylesheet' id='bootstrap-css' href='https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/themes/alamindream/assets/css/bootstrap.min.css?ver=7.1.4' media='all' />
<link rel='stylesheet' id='alamindream-fonts-css' href='https://fonts.googleapis.com/css?family=Albert+Sans%3A300%2C400%2C500%2C600%2C700%2C800%7CAlbert+Sans%3A300%2C400%2C500%2C600%2C700%2C800&#038;subset=latin%2Clatin-ext&#038;ver=7.1.4' media='all' />
<link rel='stylesheet' id='venobox-css' href='https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/themes/alamindream/venobox/venobox.css?ver=7.1.4' media='all' />
<link rel='stylesheet' id='animate-css' href='https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/themes/alamindream/assets/css/animate.css?ver=7.1.4' media='all' />
<link rel='stylesheet' id='slick-css' href='https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/themes/alamindream/assets/css/slick.css?ver=7.1.4' media='all' />
<link rel='stylesheet' id='owl-carousel-css' href='https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/themes/alamindream/assets/css/owl.carousel.css?ver=7.1.4' media='all' />
<link rel='stylesheet' id='fontawesome-css' href='https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/themes/alamindream/assets/css/font-awesome.min.css?ver=7.1.4' media='all' />
<link rel='stylesheet' id='thmemify-css' href='https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/themes/alamindream/assets/css/themify-icons.css?ver=7.1.4' media='all' />
<link rel='stylesheet' id='meanmenu-css' href='https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/themes/alamindream/assets/css/meanmenu.min.css?ver=7.1.4' media='all' />
<link rel='stylesheet' id='alamindream-theme-default-css' href='https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/themes/alamindream/assets/css/theme-default.css?ver=7.1.4' media='all' />
<link rel='stylesheet' id='alamindream-widget-css' href='https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/themes/alamindream/assets/css/widget.css?ver=7.1.4' media='all' />
<link rel='stylesheet' id='alamindream-unittest-css' href='https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/themes/alamindream/assets/css/unittest.css?ver=7.1.4' media='all' />
<link rel='stylesheet' id='alamindream-style-css' href='https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/themes/alamindream/style.css?ver=7.1.4' media='all' />
<link rel='stylesheet' id='alamindream-responsive-css' href='https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/themes/alamindream/assets/css/responsive.css?ver=7.1.4' media='all' />
<link rel='stylesheet' id='clash-css' href='https://fonts.cdnfonts.com/css/clash-display?ver=1.0' media='all' />
<link rel='stylesheet' id='hfe-elementor-icons-css' href='https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/plugins/elementor/assets/lib/eicons/css/elementor-icons.min.css?ver=5.34.0' media='all' />
<link rel='stylesheet' id='hfe-icons-list-css' href='https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/plugins/elementor/assets/css/widget-icon-list.min.css?ver=3.24.3' media='all' />
<link rel='stylesheet' id='hfe-social-icons-css' href='https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/plugins/elementor/assets/css/widget-social-icons.min.css?ver=3.24.0' media='all' />
<link rel='stylesheet' id='hfe-social-share-icons-brands-css' href='https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/plugins/elementor/assets/lib/font-awesome/css/brands.css?ver=5.15.3' media='all' />
<link rel='stylesheet' id='hfe-social-share-icons-fontawesome-css' href='https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/plugins/elementor/assets/lib/font-awesome/css/fontawesome.css?ver=5.15.3' media='all' />
<link rel='stylesheet' id='hfe-nav-menu-icons-css' href='https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/plugins/elementor/assets/lib/font-awesome/css/solid.css?ver=5.15.3' media='all' />
<link rel='stylesheet' id='alamindream-breadcrumb-css' href='https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/themes/alamindream/assets/css/em-breadcrumb.css?ver=7.1.4' media='all' />
<style id="alamindream-breadcrumb-inline-css">

					.logo img {
						;
						;
					}
					.logo a{
						margin-top:15px
					}
					.mean-container .mean-bar::before{
						content:"alamindream"						
					}											
               
/*# sourceURL=alamindream-breadcrumb-inline-css */
</style>
<link rel='stylesheet' id='elementor-gf-roboto-css' href='https://fonts.googleapis.com/css?family=Roboto:100,100italic,200,200italic,300,300italic,400,400italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic&#038;display=swap' media='all' />
<link rel='stylesheet' id='elementor-gf-robotoslab-css' href='https://fonts.googleapis.com/css?family=Roboto+Slab:100,100italic,200,200italic,300,300italic,400,400italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic&#038;display=swap' media='all' />
<link rel='stylesheet' id='elementor-gf-inter-css' href='https://fonts.googleapis.com/css?family=Inter:100,100italic,200,200italic,300,300italic,400,400italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic&#038;display=swap' media='all' />
<script id="wp-hooks-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-includes/js/dist/hooks.min.js?ver=f0f188028580e8dc1255"></script>
<script id="wp-i18n-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-includes/js/dist/i18n.min.js?ver=1dfe7db3940c23ea9216"></script>
<script id="wp-i18n-js-after">
wp.i18n.setLocaleData( { 'text direction\u0004ltr': [ 'ltr' ] } );
//# sourceURL=wp-i18n-js-after
</script>
<script id="jquery-core-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-includes/js/jquery/jquery.min.js?ver=3.7.1"></script>
<script id="jquery-migrate-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1"></script>
<script id="jquery-js-after">
!function($){"use strict";$(document).ready(function(){$(this).scrollTop()>100&&$(".hfe-scroll-to-top-wrap").removeClass("hfe-scroll-to-top-hide"),$(window).scroll(function(){$(this).scrollTop()<100?$(".hfe-scroll-to-top-wrap").fadeOut(300):$(".hfe-scroll-to-top-wrap").fadeIn(300)}),$(".hfe-scroll-to-top-wrap").on("click",function(){$("html, body").animate({scrollTop:0},300);return!1})})}(jQuery);
!function($){'use strict';$(document).ready(function(){var bar=$('.hfe-reading-progress-bar');if(!bar.length)return;$(window).on('scroll',function(){var s=$(window).scrollTop(),d=$(document).height()-$(window).height(),p=d? s/d*100:0;bar.css('width',p+'%')});});}(jQuery);
//# sourceURL=jquery-js-after
</script>
<script id="give-js-extra">
var give_global_vars = {"ajaxurl":"https://wp.dreamitsolution.net/dreamer/portfolio/wp-admin/admin-ajax.php","checkout_nonce":"8d1d1cebcf","currency":"USD","currency_sign":"$","currency_pos":"before","thousands_separator":",","decimal_separator":".","no_gateway":"Please select a payment method.","bad_minimum":"The minimum custom donation amount for this form is","bad_maximum":"The maximum custom donation amount for this form is","general_loading":"Loading...","purchase_loading":"Please Wait...","textForOverlayScreen":"\u003Ch3\u003EProcessing...\u003C/h3\u003E\u003Cp\u003EThis will only take a second!\u003C/p\u003E","number_decimals":"2","is_test_mode":"1","give_version":"4.15.2","magnific_options":{"main_class":"give-modal","close_on_bg_click":false},"form_translation":{"payment-mode":"Please select payment mode.","give_first":"Please enter your first name.","give_last":"Please enter your last name.","give_email":"Please enter a valid email address.","give_user_login":"Invalid email address or username.","give_user_pass":"Enter a password.","give_user_pass_confirm":"Enter the password confirmation.","give_agree_to_terms":"You must agree to the terms and conditions."},"confirm_email_sent_message":"Please check your email and click on the link to access your complete donation history.","ajax_vars":{"ajaxurl":"https://wp.dreamitsolution.net/dreamer/portfolio/wp-admin/admin-ajax.php","ajaxNonce":"eba2931f96","loading":"Loading","select_option":"Please select an option","default_gateway":"manual","permalinks":"1","number_decimals":2},"cookie_hash":"0e4c94abf946b3475e09cfd48a618625","session_nonce_cookie_name":"wp-give_session_reset_nonce_0e4c94abf946b3475e09cfd48a618625","session_cookie_name":"wp-give_session_0e4c94abf946b3475e09cfd48a618625","delete_session_nonce_cookie":"0"};
var giveApiSettings = {"root":"https://wp.dreamitsolution.net/dreamer/portfolio/wp-json/give-api/v2/","rest_base":"give-api/v2"};
//# sourceURL=give-js-extra
</script>
<script id="give-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/plugins/give/build/assets/dist/js/give.js?ver=8540f4f50a2032d9c5b5"></script>
<script id="cleeny-testimonial-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/themes/alamindream/assets/js/testimonial.js?ver=1"></script>
<script id="appear-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/themes/alamindream/assets/js/appear.js?ver=1"></script>
<link rel="https://api.w.org/" href="https://wp.dreamitsolution.net/dreamer/portfolio/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://wp.dreamitsolution.net/dreamer/portfolio/xmlrpc.php?rsd" />
<meta name="generator" content="WordPress 7.1.4" />
<meta name="generator" content="Redux 4.5.11" /><meta name="generator" content="Give v4.15.2" />
<meta name="generator" content="Elementor 4.0.9; features: e_font_icon_svg, additional_custom_breakpoints; settings: css_print_method-external, google_font-enabled, font_display-swap">
			<style>
				.e-con.e-parent:nth-of-type(n+4):not(.e-lazyloaded):not(.e-no-lazyload),
				.e-con.e-parent:nth-of-type(n+4):not(.e-lazyloaded):not(.e-no-lazyload) * {
					background-image: none !important;
				}
				@media screen and (max-height: 1024px) {
					.e-con.e-parent:nth-of-type(n+3):not(.e-lazyloaded):not(.e-no-lazyload),
					.e-con.e-parent:nth-of-type(n+3):not(.e-lazyloaded):not(.e-no-lazyload) * {
						background-image: none !important;
					}
				}
				@media screen and (max-height: 640px) {
					.e-con.e-parent:nth-of-type(n+2):not(.e-lazyloaded):not(.e-no-lazyload),
					.e-con.e-parent:nth-of-type(n+2):not(.e-lazyloaded):not(.e-no-lazyload) * {
						background-image: none !important;
					}
				}
			</style>
			<style id="alamindream_opt-dynamic-css" title="dynamic-css" class="redux-options-output">
					.alamindream_nav_area.prefix,
					.hbg2
					{background-color:#000000;}.breadcumb-area,.breadcumb-blog-area{background-repeat:no-repeat;background-attachment:scroll;background-position:center center;background-image:url('https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/uploads/2024/07/breatcome-bg.jpg');background-size:cover;}
					.single-video::before
					{background-color:rgba(0,0,0,0.3);}</style></head>

<body class="error404 wp-theme-alamindream give-test-mode give-page ehf-footer ehf-template-alamindream ehf-stylesheet-alamindream hfeed elementor-default elementor-kit-7">
	
	
	<!-- MAIN WRAPPER START -->
	<div class="wrapper">
						<div class="em40_header_area_main">
				
				<!-- HEADER TOP AREA -->
								
			<div class="mobile_logo_area d-sm-block d-md-block d-lg-none">
				<div class="container">
					<div class="row">
						<div class="col-sm-12">
							
	  		<div class="mobile_menu_logo text-center">
			<a href="https://wp.dreamitsolution.net/dreamer/portfolio/" title="Al-Amindream">
				<img src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/uploads/2024/07/logo.png" alt="Al-Amindream" />
			</a>		
		</div>
	  						</div>
					</div>
				</div>
			</div>

			<!-- START HEADER MAIN MENU AREA -->
						

			

				<!-- ================ REDUX OPTION ================ -->
				
					<!-- HEADER DEFAULT MANU AREA -->
					<div class="alamindream-main-menu one_page d-md-none d-lg-block d-sm-none d-none a main menu">
						<div class="alamindream_nav_area">
							<div class="container">
								<div class="row logo-left align-items-center">
									<!-- LOGO -->
									<div class="col-md-3 col-sm-3 col-xs-4">
										
	  	  
		<div class="logo">
			<a class="main_sticky_main_l standard-logo" href="https://wp.dreamitsolution.net/dreamer/portfolio/" title="Al-Amindream">
				<img src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/uploads/2024/07/logo.png" alt="Al-Amindream" />
			</a>		
		</div>	  

	  									</div>
									<div class="col-md-9 col-sm-9 col-xs-8">
										<nav class="alamindream_menu">
											<ul id="menu-main-menu" class="sub-menu"><li id="menu-item-178" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-178"><a href="#home">Home</a></li>
<li id="menu-item-179" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-179"><a href="#about">About</a></li>
<li id="menu-item-180" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-180"><a href="#service">Service</a></li>
<li id="menu-item-181" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-181"><a href="#portfolio">Portfolio</a></li>
<li id="menu-item-182" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-182"><a href="#blog">Blog</a></li>
<li id="menu-item-183" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-183"><a href="#contact">Contact</a></li>
</ul>																							<div class="donate-btn-header">
													<a class="dtbtn" href="">Get A Quote</a>
												</div>
																					</nav>
									</div>
								</div>
							</div>
						</div>
					</div>
				
						<!-- MOBILE MENU AREA -->
			<div class="home-2 mbm d-sm-block d-md-block d-lg-none header_area main-menu-area">
				<div class="menu_area mobile-menu">
					<nav>
						<ul id="menu-main-menu-1" class="main-menu clearfix"><li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-178"><a href="#home">Home</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-179"><a href="#about">About</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-180"><a href="#service">Service</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-181"><a href="#portfolio">Portfolio</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-182"><a href="#blog">Blog</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-183"><a href="#contact">Contact</a></li>
</ul>					</nav>
				</div>
			</div>
			<!-- END MOBILE MENU AREA  -->
				</div>


				<!-- Sidebar Cart Item -->
				<div class="xs-sidebar-group info-group">
					<div class="dt-overlay bt-black"></div>
					<div class="dt-sidebar-widget">
						<div class="sidebar-container">
							<div class="widget-top">
								<a href="#" class="bar-close">
									<i class="far fa-times-circle"></i>
								</a>
							</div>
							<div class="sidebar-textwidget">
								<!-- Sidebar Info Content -->
								<div class="sidebar-info-contents">
									<div class="sidebar-logo">
										
	  	  
		<div class="logo">
			<a class="main_sticky_main_l standard-logo" href="https://wp.dreamitsolution.net/dreamer/portfolio/" title="Al-Amindream">
				<img src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/uploads/2024/07/logo.png" alt="Al-Amindream" />
			</a>		
		</div>	  

	  									</div>
									<div class="sidebar-content-inner">
										<div class="sidebar-title">
											<h2>About Us</h2>
										</div>
										<div class="sidebar-desc">
											<p>The argument in favor of using filler text goes something like this: If you use real content in the Consulting Process, anytime you reach a review </p>
										</div>
										<div class="sidebar-contact-info">
											<h2>Contact Info</h2>
											<ul>
												<li>
													<i aria-hidden="true" class="flaticon flaticon-pin-1"></i>
													Chicago 12, Melborne City, USA												</li>
												<li>
													<i aria-hidden="true" class="flaticon flaticon-call"></i>
													(111) 111-111-1111												</li>
												<li>
													<i aria-hidden="true" class="flaticon flaticon-email"></i>
													Example@gmail.com												</li>
												<li>
													<i aria-hidden="true" class="flaticon flaticon-time-3"></i>
													Week Days: 09.00 to 18.00 Sunday: Closed												</li>
											</ul>
										</div>

										<!-- Social Box -->
										<div class="sidebar-social-icon">
											<ul>
												<li><a class="facebook social-icon" href="https://www.facebook.com/" title="Facebook" ><i class="fa fa-facebook"></i></a></li><li><a class="twitter social-icon" href="https://twitter.com/" title="Twitter" ><i class="fa fa-twitter"></i></a></li><li><a class="instagram social-icon" href="https://instagram.com/" title="Instagram" ><i class="fa fa-instagram"></i></a></li><li><a class="dribbble social-icon" href="https://dribbble.com/" title="Dribbble" ><i class="fa fa-dribbble"></i></a></li>											</ul>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>


		<!--start curser -->
	<div class="site_curser">
					</div>
	<!--end curser -->	<!-- BLOG BREADCUMB START -->
	<div class="breadcumb-area" >
		<div class="container">				
			<div class="row">
				<div class="col-md-12 txtc   ">
									</div>
			</div>
		</div>
	</div>
<div class="not-found-area">
	<div class="container">
		<div class="col-md-12">		
			<!-- 404 PAGE -->
			<div class="not-found">
				<div class="not-found-inner">
																404 Oops! The page you are Looking for does not exist. 						

				<div class="nf"><a href="https://wp.dreamitsolution.net/dreamer/portfolio/">Go Home</a></div>
				</div>
			</div>
			
		
		</div>
	</div>
</div>

		<footer itemtype="https://schema.org/WPFooter" itemscope="itemscope" id="colophon" role="contentinfo">
			<div class='footer-width-fixer'>		<div data-elementor-type="wp-post" data-elementor-id="165" class="elementor elementor-165">
						<section class="elementor-section elementor-top-section elementor-element elementor-element-b6f63ac elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="b6f63ac" data-element_type="section" data-e-type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
						<div class="elementor-container elementor-column-gap-no">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-05c90a8" data-id="05c90a8" data-element_type="column" data-e-type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<section class="elementor-section elementor-inner-section elementor-element elementor-element-daeb0e0 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="daeb0e0" data-element_type="section" data-e-type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-8d20789" data-id="8d20789" data-element_type="column" data-e-type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-2db2f0f elementor-widget elementor-widget-image" data-id="2db2f0f" data-element_type="widget" data-e-type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
															<img width="180" height="59" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/uploads/2024/07/logo.png" class="attachment-large size-large wp-image-169" alt="" />															</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-bd75563 footer-new-classes" data-id="bd75563" data-element_type="column" data-e-type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-1e3a471 elementor-widget elementor-widget-heading" data-id="1e3a471" data-element_type="widget" data-e-type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
					<h2 class="elementor-heading-title elementor-size-default">Let’s Talk?</h2>				</div>
				</div>
				<div class="elementor-element elementor-element-91694e6 elementor-icon-list--layout-inline elementor-align-center elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="91694e6" data-element_type="widget" data-e-type="widget" data-widget_type="icon-list.default">
				<div class="elementor-widget-container">
							<ul class="elementor-icon-list-items elementor-inline-items">
							<li class="elementor-icon-list-item elementor-inline-item">
											<a href="#">

											<span class="elementor-icon-list-text">Home</span>
											</a>
									</li>
								<li class="elementor-icon-list-item elementor-inline-item">
											<a href="#">

											<span class="elementor-icon-list-text">Portfoio</span>
											</a>
									</li>
								<li class="elementor-icon-list-item elementor-inline-item">
											<a href="#">

											<span class="elementor-icon-list-text">Blog</span>
											</a>
									</li>
								<li class="elementor-icon-list-item elementor-inline-item">
											<a href="#">

											<span class="elementor-icon-list-text">Contact</span>
											</a>
									</li>
						</ul>
						</div>
				</div>
				<div class="elementor-element elementor-element-2463bd5 elementor-widget elementor-widget-heading" data-id="2463bd5" data-element_type="widget" data-e-type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
					<p class="elementor-heading-title elementor-size-default">© All rights reserved by DreamIT</p>				</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-d35b8cc" data-id="d35b8cc" data-element_type="column" data-e-type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-0c94a1f elementor-widget elementor-widget-dit-button" data-id="0c94a1f" data-element_type="widget" data-e-type="widget" data-widget_type="dit-button.default">
				<div class="elementor-widget-container">
					
		
			<div class="dreamit-button style5">
			    
			    <div class="dreamit-button">
				<a class="button" href="">
					Let's Chart																				</a>
				</div>
			</div>
				
					</div>
				</div>
					</div>
		</div>
					</div>
		</section>
					</div>
		</div>
					</div>
		</section>
				</div>
		</div>		</footer>
	</div><!-- #page -->
<script type="speculationrules">
{"prefetch":[{"source":"document","where":{"and":[{"href_matches":"/dreamer/portfolio/*"},{"not":{"href_matches":["/dreamer/portfolio/wp-*.php","/dreamer/portfolio/wp-admin/*","/dreamer/portfolio/wp-content/uploads/*","/dreamer/portfolio/wp-content/*","/dreamer/portfolio/wp-content/plugins/*","/dreamer/portfolio/wp-content/themes/alamindream/*","/dreamer/portfolio/*\\?(.+)"]}},{"not":{"selector_matches":"a[rel~=\"nofollow\"]"}},{"not":{"selector_matches":".no-prefetch, .no-prefetch a"}}]},"eagerness":"conservative"}]}
</script>
<script id="wp-importmap" type="importmap">
{"imports":{"@wordpress/video-conversion/worker":"https://wp.dreamitsolution.net/dreamer/portfolio/wp-includes/js/dist/script-modules/video-conversion/worker.min.js?ver=4d3627c45251ceb4f9a2","@wordpress/vips/worker":"https://wp.dreamitsolution.net/dreamer/portfolio/wp-includes/js/dist/script-modules/vips/worker.min.js?ver=7e33cd8c4128731126e8"}}
</script>
			<script>
				const lazyloadRunObserver = () => {
					const lazyloadBackgrounds = document.querySelectorAll( `.e-con.e-parent:not(.e-lazyloaded)` );
					const lazyloadBackgroundObserver = new IntersectionObserver( ( entries ) => {
						entries.forEach( ( entry ) => {
							if ( entry.isIntersecting ) {
								let lazyloadBackground = entry.target;
								if( lazyloadBackground ) {
									lazyloadBackground.classList.add( 'e-lazyloaded' );
								}
								lazyloadBackgroundObserver.unobserve( entry.target );
							}
						});
					}, { rootMargin: '200px 0px 200px 0px' } );
					lazyloadBackgrounds.forEach( ( lazyloadBackground ) => {
						lazyloadBackgroundObserver.observe( lazyloadBackground );
					} );
				};
				const events = [
					'DOMContentLoaded',
					'elementor/lazyload/observe',
				];
				events.forEach( ( event ) => {
					document.addEventListener( event, lazyloadRunObserver );
				} );
			</script>
			<link rel='stylesheet' id='widget-icon-list-css' href='https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/plugins/elementor/assets/css/widget-icon-list.min.css?ver=4.0.9' media='all' />
<script id="swv-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/plugins/contact-form-7/includes/swv/js/index.js?ver=6.1.6"></script>
<script id="contact-form-7-js-before">
var wpcf7 = {
    "api": {
        "root": "https:\/\/wp.dreamitsolution.net\/dreamer\/portfolio\/wp-json\/",
        "namespace": "contact-form-7\/v1"
    }
};
//# sourceURL=contact-form-7-js-before
</script>
<script id="contact-form-7-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/plugins/contact-form-7/includes/js/index.js?ver=6.1.6"></script>
<script id="react-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-includes/js/dist/vendor/react.min.js?ver=18.3.1.1"></script>
<script id="react-jsx-runtime-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-includes/js/dist/vendor/react-jsx-runtime.min.js?ver=18.3.1"></script>
<script id="wp-private-apis-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-includes/js/dist/private-apis.min.js?ver=eb85f28c4c729bb4f002"></script>
<script id="wp-url-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-includes/js/dist/url.min.js?ver=7b0de086d4ae11d55704"></script>
<script id="wp-api-fetch-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-includes/js/dist/api-fetch.min.js?ver=6f2a4faeee3c722b1e57"></script>
<script id="wp-api-fetch-js-after">
wp.apiFetch.use( wp.apiFetch.createRootURLMiddleware( "https://wp.dreamitsolution.net/dreamer/portfolio/wp-json/" ) );
wp.apiFetch.nonceMiddleware = wp.apiFetch.createNonceMiddleware( "9f4783bd85" );
wp.apiFetch.use( wp.apiFetch.nonceMiddleware );
wp.apiFetch.use( wp.apiFetch.mediaUploadMiddleware );
wp.apiFetch.nonceEndpoint = "https://wp.dreamitsolution.net/dreamer/portfolio/wp-admin/admin-ajax.php?action=rest-nonce";
(function(){if(!window.wp||!wp.apiFetch||!wp.apiFetch.use){return;}wp.apiFetch.use(function(options,next){var p=String((options&&(options.path||options.url))||"");try{var u=new URL(p,window.location.origin);p=(u.pathname||"")+(u.search||"");}catch(e){}if(p.indexOf("/wp/v2/users/me")!==-1){return Promise.resolve(null);}return next(options);});})();
//# sourceURL=wp-api-fetch-js-after
</script>
<script id="react-dom-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-includes/js/dist/vendor/react-dom.min.js?ver=18.3.1.1"></script>
<script id="wp-dom-ready-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-includes/js/dist/dom-ready.min.js?ver=3fe927cab37bf38d6a23"></script>
<script id="wp-a11y-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-includes/js/dist/a11y.min.js?ver=31c6cec5a4ff7aff483d"></script>
<script id="wp-blob-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-includes/js/dist/blob.min.js?ver=c7582a735ddd2edc9731"></script>
<script id="wp-block-serialization-default-parser-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-includes/js/dist/block-serialization-default-parser.min.js?ver=fc209395a022242d64aa"></script>
<script id="wp-autop-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-includes/js/dist/autop.min.js?ver=4e10a18cb6f21a043fc0"></script>
<script id="wp-deprecated-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-includes/js/dist/deprecated.min.js?ver=fe587bac92b7d0ef760e"></script>
<script id="wp-dom-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-includes/js/dist/dom.min.js?ver=c95f94cbbc1ac3fde84f"></script>
<script id="wp-escape-html-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-includes/js/dist/escape-html.min.js?ver=87ebe53e97bba59805a5"></script>
<script id="wp-element-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-includes/js/dist/element.min.js?ver=4a4370b2b349066fd440"></script>
<script id="wp-is-shallow-equal-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-includes/js/dist/is-shallow-equal.min.js?ver=7ad271045c1fe60f5496"></script>
<script id="wp-keycodes-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-includes/js/dist/keycodes.min.js?ver=d0b4204e4bbeb412df6e"></script>
<script id="wp-priority-queue-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-includes/js/dist/priority-queue.min.js?ver=6c0aa59b65d55dfd509b"></script>
<script id="wp-undo-manager-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-includes/js/dist/undo-manager.min.js?ver=4554fce6276d8910a4ae"></script>
<script id="wp-compose-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-includes/js/dist/compose.min.js?ver=0e8bde2a499ea6073b42"></script>
<script id="wp-redux-routine-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-includes/js/dist/redux-routine.min.js?ver=acca2b4857d83ad1790e"></script>
<script id="wp-data-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-includes/js/dist/data.min.js?ver=14a216e0932d72c22976"></script>
<script id="wp-data-js-after">
( function() {
	var userId = 0;
	var storageKey = "WP_DATA_USER_" + userId;
	wp.data
		.use( wp.data.plugins.persistence, { storageKey: storageKey } );
} )();
//# sourceURL=wp-data-js-after
</script>
<script id="wp-html-entities-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-includes/js/dist/html-entities.min.js?ver=a976ff3a0f00bc2999a3"></script>
<script id="wp-rich-text-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-includes/js/dist/rich-text.min.js?ver=3e5852e42cee1c239bae"></script>
<script id="wp-shortcode-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-includes/js/dist/shortcode.min.js?ver=f6273476300cc5fad4cd"></script>
<script id="wp-warning-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-includes/js/dist/warning.min.js?ver=a0978839debc564a6608"></script>
<script id="wp-blocks-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-includes/js/dist/blocks.min.js?ver=c0e57a630a0b6f6c3bb5"></script>
<script id="moment-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-includes/js/dist/vendor/moment.min.js?ver=2.30.1"></script>
<script id="moment-js-after">
moment.updateLocale( 'en_US', {"months":["January","February","March","April","May","June","July","August","September","October","November","December"],"monthsShort":["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],"weekdays":["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],"weekdaysShort":["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],"week":{"dow":1},"longDateFormat":{"LT":"g:i a","LTS":null,"L":null,"LL":"F j, Y","LLL":"F j, Y g:i a","LLLL":null}} );
//# sourceURL=moment-js-after
</script>
<script id="wp-date-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-includes/js/dist/date.min.js?ver=8173fc0fc12b7bb7eaf0"></script>
<script id="wp-date-js-after">
wp.date.setSettings( {"l10n":{"locale":"en_US","months":["January","February","March","April","May","June","July","August","September","October","November","December"],"monthsShort":["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],"weekdays":["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],"weekdaysShort":["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],"meridiem":{"am":"am","pm":"pm","AM":"AM","PM":"PM"},"relative":{"future":"%s from now","past":"%s ago","s":"a second","ss":"%d seconds","m":"a minute","mm":"%d minutes","h":"an hour","hh":"%d hours","d":"a day","dd":"%d days","M":"a month","MM":"%d months","y":"a year","yy":"%d years"},"startOfWeek":1},"formats":{"time":"g:i a","date":"F j, Y","datetime":"F j, Y g:i a","datetimeAbbreviated":"M j, Y g:i a"},"timezone":{"offset":0,"offsetFormatted":"0","string":"","abbr":""}} );
//# sourceURL=wp-date-js-after
</script>
<script id="wp-primitives-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-includes/js/dist/primitives.min.js?ver=44cc5a35c7b9fe07a838"></script>
<script id="wp-theme-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-includes/js/dist/theme.min.js?ver=56a75cc08ae66c1fcb7a"></script>
<script id="wp-components-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-includes/js/dist/components.min.js?ver=9b751f17060211272a5c"></script>
<script id="wp-keyboard-shortcuts-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-includes/js/dist/keyboard-shortcuts.min.js?ver=37da95806f2339bc80d0"></script>
<script id="wp-preferences-persistence-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-includes/js/dist/preferences-persistence.min.js?ver=a34abbdacd8f50f9acb1"></script>
<script id="wp-preferences-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-includes/js/dist/preferences.min.js?ver=5a169e3fc0e657f74172"></script>
<script id="wp-preferences-js-after">
( function() {
				var serverData = false;
				var userId = "0";
				var persistenceLayer = wp.preferencesPersistence.__unstableCreatePersistenceLayer( serverData, userId );
				var preferencesStore = wp.preferences.store;
				wp.data.dispatch( preferencesStore ).setPersistenceLayer( persistenceLayer );
			} ) ();
//# sourceURL=wp-preferences-js-after
</script>
<script id="wp-commands-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-includes/js/dist/commands.min.js?ver=1a4910212c7ed2355300"></script>
<script id="wp-notices-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-includes/js/dist/notices.min.js?ver=c09a068fdab0eb465e14"></script>
<script id="wp-style-engine-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-includes/js/dist/style-engine.min.js?ver=914befb08774033e6265"></script>
<script id="wp-token-list-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-includes/js/dist/token-list.min.js?ver=e86ab419d8302d57822c"></script>
<script id="wp-upload-media-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-includes/js/dist/upload-media.min.js?ver=a2c026d433c295fd5145"></script>
<script id="wp-block-editor-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-includes/js/dist/block-editor.min.js?ver=37e58da384b2558bd479"></script>
<script id="wp-core-data-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-includes/js/dist/core-data.min.js?ver=573f98dbff9f49ffeb0b"></script>
<script id="givewp-entities-public-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/plugins/give/build/entitiesPublic.js?ver=b759f2adda1f29c50713"></script>
<script id="owl-script-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/plugins/dreamit-elementor-extension/assets/js/owl.carousel.min.js?ver=1.1"></script>
<script id="widgets-script-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/plugins/dreamit-elementor-extension/assets/js/widgets-script.js?ver=1.1"></script>
<script id="tabscript-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/plugins/dreamit-elementor-extension/assets/js/tabscript.js?ver=1.1"></script>
<script id="modernizrs-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/themes/alamindream/assets/js/modernizr.custom.79639.js?ver=3.2.4"></script>
<script id="modernizr-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/themes/alamindream/assets/js/vendor/modernizr-2.8.3.min.js?ver=2.8.3"></script>
<script id="bootstrap-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/themes/alamindream/assets/js/bootstrap.min.js?ver=3.3.5"></script>
<script id="imagesloaded-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-includes/js/imagesloaded.min.js?ver=5.0.0"></script>
<script id="meanmenu-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/themes/alamindream/assets/js/jquery.meanmenu.js?ver=1.0.0"></script>
<script id="isotope-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/themes/alamindream/assets/js/isotope.pkgd.min.js?ver=1.0.0"></script>
<script id="owl-carousel-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/themes/alamindream/assets/js/owl.carousel.min.js?ver=7.1.4"></script>
<script id="scrollup-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/themes/alamindream/assets/js/jquery.scrollUp.js?ver=3.2.4"></script>
<script id="paralax-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/themes/alamindream/assets/js/parallax.min.js?ver=3.2.4"></script>
<script id="jquery-counterup-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/themes/alamindream/assets/js/jquery.counterup.min.js?ver=3.2.4"></script>
<script id="slick-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/themes/alamindream/assets/js/slick.min.js?ver=3.2.4"></script>
<script id="jquery-nav-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/themes/alamindream/assets/js/jquery.nav.js?ver=3.2.4"></script>
<script id="wow-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/themes/alamindream/assets/js/wow.js?ver=3.2.4"></script>
<script id="jquery-scrolltofixed-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/themes/alamindream/assets/js/jquery-scrolltofixed-min.js?ver=3.2.4"></script>
<script id="venobox-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/themes/alamindream/venobox/venobox.min.js?ver=3.2.4"></script>
<script id="waypoints-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/themes/alamindream/assets/js/waypoints.min.js?ver=3.2.4"></script>
<script id="alamindream-navigation-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/themes/alamindream/assets/js/navigation.js?ver=20151215"></script>
<script id="alamindream-skip-link-focus-fix-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/themes/alamindream/assets/js/skip-link-focus-fix.js?ver=20151215"></script>
<script id="alamindream-theme-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/themes/alamindream/assets/js/theme.js?ver=3.2.4"></script>
<script id="elementor-webpack-runtime-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/plugins/elementor/assets/js/webpack.runtime.min.js?ver=4.0.9"></script>
<script id="elementor-frontend-modules-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/plugins/elementor/assets/js/frontend-modules.min.js?ver=4.0.9"></script>
<script id="jquery-ui-core-js-before">
jQuery.uiBackCompat = true;
//# sourceURL=jquery-ui-core-js-before
</script>
<script id="jquery-ui-core-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-includes/js/jquery/ui/core.min.js?ver=1.14.2"></script>
<script id="elementor-frontend-js-before">
var elementorFrontendConfig = {"environmentMode":{"edit":false,"wpPreview":false,"isScriptDebug":false},"i18n":{"shareOnFacebook":"Share on Facebook","shareOnTwitter":"Share on Twitter","pinIt":"Pin it","download":"Download","downloadImage":"Download image","fullscreen":"Fullscreen","zoom":"Zoom","share":"Share","playVideo":"Play Video","previous":"Previous","next":"Next","close":"Close","a11yCarouselPrevSlideMessage":"Previous slide","a11yCarouselNextSlideMessage":"Next slide","a11yCarouselFirstSlideMessage":"This is the first slide","a11yCarouselLastSlideMessage":"This is the last slide","a11yCarouselPaginationBulletMessage":"Go to slide"},"is_rtl":false,"breakpoints":{"xs":0,"sm":480,"md":768,"lg":1025,"xl":1440,"xxl":1600},"responsive":{"breakpoints":{"mobile":{"label":"Mobile Portrait","value":767,"default_value":767,"direction":"max","is_enabled":true},"mobile_extra":{"label":"Mobile Landscape","value":880,"default_value":880,"direction":"max","is_enabled":false},"tablet":{"label":"Tablet Portrait","value":1024,"default_value":1024,"direction":"max","is_enabled":true},"tablet_extra":{"label":"Tablet Landscape","value":1200,"default_value":1200,"direction":"max","is_enabled":false},"laptop":{"label":"Laptop","value":1366,"default_value":1366,"direction":"max","is_enabled":false},"widescreen":{"label":"Widescreen","value":2400,"default_value":2400,"direction":"min","is_enabled":false}},"hasCustomBreakpoints":false},"version":"4.0.9","is_static":false,"experimentalFeatures":{"e_font_icon_svg":true,"additional_custom_breakpoints":true,"global_classes_should_enforce_capabilities":true,"e_variables":true,"e_opt_in_v4_page":true,"e_components":true,"e_interactions":true,"e_widget_creation":true,"import-export-customization":true},"urls":{"assets":"https:\/\/wp.dreamitsolution.net\/dreamer\/portfolio\/wp-content\/plugins\/elementor\/assets\/","ajaxurl":"https:\/\/wp.dreamitsolution.net\/dreamer\/portfolio\/wp-admin\/admin-ajax.php","uploadUrl":"https:\/\/wp.dreamitsolution.net\/dreamer\/portfolio\/wp-content\/uploads"},"nonces":{"floatingButtonsClickTracking":"ea7b9a76a7","atomicFormsSendForm":"c742484e8c"},"swiperClass":"swiper","settings":{"editorPreferences":[]},"kit":{"active_breakpoints":["viewport_mobile","viewport_tablet"],"global_image_lightbox":"yes","lightbox_enable_counter":"yes","lightbox_enable_fullscreen":"yes","lightbox_enable_zoom":"yes","lightbox_enable_share":"yes","lightbox_title_src":"title","lightbox_description_src":"description"},"post":{"id":0,"title":"Page not found &#8211; Al-Amindream","excerpt":""}};
//# sourceURL=elementor-frontend-js-before
</script>
<script id="elementor-frontend-js" src="https://wp.dreamitsolution.net/dreamer/portfolio/wp-content/plugins/elementor/assets/js/frontend.min.js?ver=4.0.9"></script>
<script id="wp-emoji-settings" type="application/json">
{"baseUrl":"https://s.w.org/images/core/emoji/17.0.2/72x72/","ext":".png","svgUrl":"https://s.w.org/images/core/emoji/17.0.2/svg/","svgExt":".svg","source":{"concatemoji":"https://wp.dreamitsolution.net/dreamer/portfolio/wp-includes/js/wp-emoji-release.min.js?ver=7.1.4"}}
</script>
<script type="module">
/*! This file is auto-generated */
var e="script#wp-emoji-settings",t=document.querySelector(e);if(!(t instanceof HTMLScriptElement))throw new Error("Element missing: "+e);const r=JSON.parse(t.text),s=(window._wpemojiSettings=r,"wpEmojiSettingsSupports"),o=["flag","emoji"];function i(e){try{var t={supportTests:e,timestamp:(new Date).valueOf()};sessionStorage.setItem(s,JSON.stringify(t))}catch(e){}}function c(e,t,n){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);t=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data);e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(n,0,0);const r=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data);return t.every((e,t)=>e===r[t])}function p(e,t){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);var n=e.getImageData(16,16,1,1);for(let e=0;e<n.data.length;e++)if(0!==n.data[e])return!1;return!0}function u(e,t,n,r){switch(t){case"flag":return n(e,"\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f","\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f")?!1:!n(e,"\ud83c\udde8\ud83c\uddf6","\ud83c\udde8\u200b\ud83c\uddf6")&&!n(e,"\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f","\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f");case"emoji":return!r(e,"\ud83e\u1fac8")}return!1}function f(e,t,n,r){let a;const s=(a="undefined"!=typeof WorkerGlobalScope&&self instanceof WorkerGlobalScope?new OffscreenCanvas(300,150):document.createElement("canvas")).getContext("2d",{willReadFrequently:!0}),o=(s.textBaseline="top",s.font="600 32px Arial",{});return e.forEach(e=>{o[e]=t(s,e,n,r)}),o}function a(e){var t=document.createElement("script");t.src=e,t.defer=!0,document.head.appendChild(t)}r.supports={everything:!0,everythingExceptFlag:!0},new Promise(t=>{let n=function(){try{var e=JSON.parse(sessionStorage.getItem(s));if("object"==typeof e&&"number"==typeof e.timestamp&&(new Date).valueOf()<e.timestamp+604800&&"object"==typeof e.supportTests)return e.supportTests}catch(e){}return null}();if(!n){if("undefined"!=typeof Worker&&"undefined"!=typeof OffscreenCanvas&&"undefined"!=typeof URL&&URL.createObjectURL&&"undefined"!=typeof Blob)try{var e="postMessage("+f.toString()+"("+[JSON.stringify(o),u.toString(),c.toString(),p.toString()].join(",")+"));",r=new Blob([e],{type:"text/javascript"});const a=new Worker(URL.createObjectURL(r),{name:"wpTestEmojiSupports"});return void(a.onmessage=e=>{i(n=e.data),a.terminate(),t(n)})}catch(e){}i(n=f(o,u,c,p))}t(n)}).then(e=>{for(const n in e)r.supports[n]=e[n],r.supports.everything=r.supports.everything&&r.supports[n],"flag"!==n&&(r.supports.everythingExceptFlag=r.supports.everythingExceptFlag&&r.supports[n]);var t;r.supports.everythingExceptFlag=r.supports.everythingExceptFlag&&!r.supports.flag,r.supports.everything||((t=r.source||{}).concatemoji?a(t.concatemoji):t.wpemoji&&t.twemoji&&(a(t.twemoji),a(t.wpemoji)))});
//# sourceURL=https://wp.dreamitsolution.net/dreamer/portfolio/wp-includes/js/wp-emoji-loader.min.js
</script>
</body>
</html> 
